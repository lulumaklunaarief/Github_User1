package com.dicoding.githubuser.ui.main

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.dicoding.githubuser.DetailUserActivity
import com.dicoding.githubuser.R
import com.dicoding.githubuser.data.response.GithubDetailUsersResponse
import com.dicoding.githubuser.data.response.GithubSearchUsersResponse
import com.dicoding.githubuser.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.dicoding.githubuser.ui.main.FollowAdapter as FollowPagerAdapter

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

//    val followPagerAdapter = FollowPagerAdapter(this)
    val viewPager: ViewPager2 = findViewById(R.id.view_pager)
    val tabs: TabLayout = findViewById(R.id.tab)
    val sectionsPagerAdapter = SectionPagerAdapter(this, supportFragmentManager)

    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val model = ViewModelProvider(this).get(UserViewModel::class.java)
        model.getUsers().observe(this) {
            if (it!= null) {
                val adapter = null
                adapter.setList(it)

            }

        }
        model.showLoading.observe(this) {
            _showLoading(it)
        }

        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f
    }

    private fun _showLoading(it: Boolean?) {

    }

    private fun showLoading(isLoading: Boolean) = if (isLoading) {
        binding.progressBar.visibility = View.VISIBLE
    } else {
        binding.progressBar.visibility = View.GONE
    }

    private fun showSelectedHero(githubDetailUsersResponse: GithubDetailUsersResponse) {
        Toast.makeText(this, "Kamu memilih " + githubDetailUsersResponse.login, Toast.LENGTH_SHORT).show()
        val intentToDetail = Intent(this@MainActivity, GithubDetailUsersResponse::class.java)
        intentToDetail.putExtra("DATA", githubDetailUsersResponse)
        startActivity(intentToDetail)
    }
}

private fun Intent.putExtra(s: String, githubDetailUsersResponse: GithubDetailUsersResponse) {

}

private fun Nothing?.setList(it: GithubSearchUsersResponse) {

}

