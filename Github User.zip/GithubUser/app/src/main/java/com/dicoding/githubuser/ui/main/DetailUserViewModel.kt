package com.dicoding.githubuser.ui.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.githubuser.data.response.FollowersResponse
import com.dicoding.githubuser.data.response.GithubDetailUsersResponse
import com.dicoding.githubuser.data.response.ItemsItem
import com.dicoding.githubuser.data.retrofit.ApiConfig
import com.dicoding.githubuser.data.retrofit.ApiService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailUserViewModel: ViewModel() {
    val user = MutableLiveData<GithubDetailUsersResponse>()
    val userFollowers = MutableLiveData<FollowersResponse>()
    val userFollowing = MutableLiveData<FollowersResponse>()

    private val _showLoading = MutableLiveData<Boolean>()
    val showLoading: LiveData<Boolean> = _showLoading


    fun setUserDetail(username: String) {
        _showLoading.value = true
        ApiConfig.getApiService()
            .getDetailUser(username)
            .enqueue(object : Callback<GithubDetailUsersResponse> {
                override fun onResponse(
                    call: Call<GithubDetailUsersResponse>,
                    response: Response<GithubDetailUsersResponse>
                ) {
                    if (response.isSuccessful) {
                        user.postValue(response.body())
                        _showLoading.value = false
                    }
                }

                override fun onFailure(call: Call<GithubDetailUsersResponse>, t: Throwable) {
                    val log = null
                    log.d("failure", t.message)
                    _showLoading.value = false
                }


            })

    }
    fun getUserDetail(): LiveData<GithubDetailUsersResponse> {
        return user
    }
    fun getFollowers(username: String) {
        _showLoading.value = true
        ApiConfig.getApiService()
            .getFollowers(username)
            .enqueue(object : Callback<List<ItemsItem>> {
                override fun onResponse(
                    call: Call<List<ItemsItem>>,
                    response: Response<List<ItemsItem>>
                ) {
                    if (response.isSuccessful) {
                        user.postValue(response.body())
                        _showLoading.value = false
                    }
                }

                override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                    val log = null
                    log.d("failure", t.message)
                    _showLoading.value = false
                }
            })

    }
    fun getFollowing(username: String) {
        _showLoading.value = true
        ApiConfig.getApiService()
            .getFollowing(username)
            .enqueue(object : Callback<List<ItemsItem>> {
                override fun onResponse(
                    call: Call<List<ItemsItem>>,
                    response: Response<List<ItemsItem>>
                ) {
                    if (response.isSuccessful) {
                        user.postValue(response.body())
                        _showLoading.value = false
                    }
                }

                override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                    val log = null
                    log.d("failure", t.message)
                    _showLoading.value = false
                }

            })
    }

}

private fun <T> MutableLiveData<T>.postValue(body: List<ItemsItem>?) {

}



private fun Nothing?.d(s: String, message: String?) {

}
