package com.dicoding.githubuser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.dicoding.githubuser.data.response.GithubDetailUsersResponse
import com.dicoding.githubuser.data.retrofit.ApiConfig
import com.dicoding.githubuser.databinding.ActivityDetailUserBinding
import com.dicoding.githubuser.ui.main.DetailUserViewModel
import com.dicoding.githubuser.ui.main.SectionPagerAdapter
import com.google.android.material.tabs.TabLayout
import retrofit2.Call
import retrofit2.Response

class DetailUserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailUserBinding

    val viewPager: ViewPager2 = findViewById(R.id.view_pager)
    val tabs: TabLayout = findViewById(R.id.tab)


//    val fragmentManager = supportFragmentManager
//    val followFragment = FollowFragment()
//    val fragment = fragmentManager.findFragmentByTag(FollowFragment::class.java.simpleName)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)



        supportActionBar?.title = "Detail Github User"

        val getIntent = intent.getStringExtra(EXTRA_USER).toString()


        ApiConfig.getApiService().getDetailUser(getIntent).enqueue(object: retrofit2.Callback<GithubDetailUsersResponse>{
            override fun onResponse(
                call: Call<GithubDetailUsersResponse>,
                response: Response<GithubDetailUsersResponse>
            ) {
                val body = response.body()
                if (response.isSuccessful && body != null) {
                    Log.i("TAG", "##### response = $body")
                    binding.tvNamaUser.text = body.login
                    binding.tvFollowers.text = "${body.followers.toString()} followers"
                    binding.tvFollowing.text = "${body.following.toString()} following"
                    binding.tvUsername.text = body.name
                    Glide.with(binding.root)
                        .load(body.avatarUrl)
                        .into(binding.imgProfile)

                }
            }

            override fun onFailure(call: Call<GithubDetailUsersResponse>, t: Throwable) {

            }

        })


//        binding.tvNamaUser.text = getIntent

//        if (fragment !is FollowFragment) {
//            Log.d(
//                "TAG",
//                "onResponse Body =body.totalCount.toString()" + FollowFragment::class.java.simpleName
//            )
//            fragmentManager
//                .beginTransaction()
//                .add(R.id.section_label, followFragment, FollowFragment::class.java.simpleName)
//                .commit()
//        }

    }

    companion object {
        const val EXTRA_USER = "extra_user"
    }
}


//    fun onClick(v: View?) {
//        if (v?.id == R.id.following_page) {
//
//            fragmentManager.beginTransaction().apply {
//                replace(R.id.following_page, followFragment, FollowingFragment::class.java.simpleName)
//                addToBackStack(null)
//                commit()
//            }
//        }
//    }
//
//    private fun replace(followingPage: Int, followFragment: FollowFragment.Companion, simpleName: String) {
//
//    }



