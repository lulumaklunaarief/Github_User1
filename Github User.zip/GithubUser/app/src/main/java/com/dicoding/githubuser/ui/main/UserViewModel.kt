package com.dicoding.githubuser.ui.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.githubuser.data.response.GithubSearchUsersResponse
import androidx.lifecycle.MutableLiveData as MutableLiveData

class UserViewModel : ViewModel() {

    val listUsers = MutableLiveData<ArrayList<GithubSearchUsersResponse>>()
    private val _showLoading = MutableLiveData<Boolean>()
    val showLoading: LiveData<Boolean> = _showLoading

    private val users: MutableLiveData<GithubSearchUsersResponse> by lazy {
        MutableLiveData<GithubSearchUsersResponse>().also {
            loadUsers()
        }
    }




    fun getUsers(): LiveData<GithubSearchUsersResponse> {
        return users
    }

    private fun loadUsers() {
        // Do an asynchronous operation to fetch users.
        _showLoading.value = true
    }
}
