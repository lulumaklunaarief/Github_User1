package com.dicoding.githubuser

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubuser.data.response.GithubSearchUsersResponse
import com.dicoding.githubuser.data.retrofit.ApiConfig
import com.dicoding.githubuser.databinding.ActivityMenuBinding
import com.dicoding.githubuser.ui.UserAdapter
import com.dicoding.githubuser.ui.main.UserViewModel
import retrofit2.Call
import retrofit2.Response

class MenuActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMenuBinding
    private lateinit var userAdapter: UserAdapter
    private lateinit var userViewModel: UserViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        binding.searchBar.setText("string")
        with(binding) {
            userAdapter = UserAdapter {

            }
            userName.layoutManager = LinearLayoutManager(this@MenuActivity)
            userName.adapter = userAdapter
            searchBar.inflateMenu(R.menu.option_menu)
//            searchBar.setOnMenuItemClickListener {
//                when(it.itemId) {
//                    R.id.menu1 -> {
//                        true
//                    }
//                }
//            }
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    binding.searchBar.setText(searchView.text)
                    searchView.hide()
                    showLoading(true)
                    ApiConfig.getApiService().getUsers(searchView.text.toString()).enqueue(object: retrofit2.Callback<GithubSearchUsersResponse>{
                        override fun onResponse(
                            call: Call<GithubSearchUsersResponse>,
                            response: Response<GithubSearchUsersResponse>
                        ) {
                            val body = response.body()
                            showLoading(false)
                            if (response.isSuccessful && body != null) {
                                userAdapter.submitList(body.items)
                                Log.d("TAG", "onResponse Body =body.totalCount.toString()")
                                Log.d("TAG", "onResponse response =response.isSuccessful.toString()")
                            }
                        }

                        override fun onFailure(
                            call: Call<GithubSearchUsersResponse>,
                            t: Throwable
                        ) {
                            showLoading(false)

                        }
                    })
                    Toast.makeText(this@MenuActivity, searchView.text, Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }
        private fun showLoading(isLoading: Boolean) = if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
