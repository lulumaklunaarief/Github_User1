package com.dicoding.githubuser.ui.main

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubuser.databinding.FragmentFollowBinding
import com.dicoding.githubuser.ui.UserAdapter

class FollowFragment : Fragment() {

    private var position: Int? = null
    private var username: String? = null
    private lateinit var binding: FragmentFollowBinding
    private val detailViewModel: DetailUserViewModel by viewModels<DetailUserViewModel>()
    private val adapter by lazy {
        UserAdapter {

        }

    }

//    val index = arguments?.getInt(ARG_SECTION_NUMBER, 0)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFollowBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvFollow.apply {
            layoutManager = LinearLayoutManager(requireActivity())
            setHasFixedSize(true)
            adapter = this@FollowFragment.adapter
        }
        arguments?.let {
            position = it.getInt(ARG_POSITION)
            username = it.getString(ARG_USERNAME)
        }
        if (position == 1) {



        }



    }

    companion object {
        val ARG_USERNAME: String?
            get() {
                TODO()
            }
        const val ARG_POSITION = "posisi"
        fun newInstance(param1: String, param2: String) = FollowFragment()
    }
}