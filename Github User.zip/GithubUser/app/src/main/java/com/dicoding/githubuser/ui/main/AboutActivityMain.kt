package com.dicoding.githubuser.ui.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.githubuser.R

class AboutActivityMain: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.setTitle("Github User")
    }
}